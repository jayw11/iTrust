INSERT INTO transactionlog(loggedInMID, secondaryMID, transactionCode, timeLogged, addedInfo) 
                    VALUES 
					   (9000000000, 0, 1, '2007-06-23 06:54:59','');
