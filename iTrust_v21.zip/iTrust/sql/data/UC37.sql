INSERT INTO allergies(
	PatientID,
	Description,
	Code,
	FirstFound,
)
VALUES (25,'Penicillin','664662530','2012-2-3');